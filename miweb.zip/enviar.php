<?php
$nombre = $_POST['nombre']; //variable
$correo = $_POST['correo'];
$mensaje = $_POST['comentarios'];
$para = "austry.castillo@educacionit.com";
$asunto = "Contacto desde mi web";
$cuerpo = "<h1>Contacto web</h1>";
$cuerpo .= "<img src=https://es.freelogodesign.org/Content/img/logo-samples/flooop.png>";
$cuerpo .= "<br><br>Los datos recibidos son<br>";
$cuerpo .= "Nombre: " . $nombre;
$cuerpo .= "<br>Correo: " . $correo;
$cuerpo .= "<br>Comentarios:" . $mensaje;
$cabecera = "From:" . $para . "\r\n";
$cabecera .= "MIME-Version: 1.0\r\n";
$cabecera .= "Content-Type: text/html; charset=UTF-8\r\n";
if (mail($para, $asunto, $cuerpo, $cabecera)) {
    echo "correo enviado";
} else {
    echo "error, no puedo enviar el correo";
}
